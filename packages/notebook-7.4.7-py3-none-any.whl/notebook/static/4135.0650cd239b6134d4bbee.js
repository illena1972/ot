"use strict";
(self["webpackChunk_JUPYTERLAB_CORE_OUTPUT"] = self["webpackChunk_JUPYTERLAB_CORE_OUTPUT"] || []).push([[4135],{

/***/ 74135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   diagram: () => (/* binding */ diagram)
/* harmony export */ });
/* harmony import */ var _chunk_B4BG7PRW_mjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(94682);
/* harmony import */ var _chunk_FMBD7UC4_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(28862);
/* harmony import */ var _chunk_55IACEB6_mjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(40448);
/* harmony import */ var _chunk_QN33PNHL_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(51755);
/* harmony import */ var _chunk_N4CR4FBY_mjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(54160);
/* harmony import */ var _chunk_QXUST7PY_mjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(55195);
/* harmony import */ var _chunk_HN2XXSSU_mjs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(67894);
/* harmony import */ var _chunk_JZLCHNYA_mjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(26212);
/* harmony import */ var _chunk_CVBHYZKI_mjs__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(22462);
/* harmony import */ var _chunk_ATLVNIR6_mjs__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(37756);
/* harmony import */ var _chunk_JA3XYJ7Z_mjs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2111);
/* harmony import */ var _chunk_S3R3BYOJ_mjs__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(17175);
/* harmony import */ var _chunk_ABZYJK2D_mjs__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(61805);
/* harmony import */ var _chunk_AGHRB4JF_mjs__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(74999);















// src/diagrams/class/classDiagram-v2.ts
var diagram = {
  parser: _chunk_B4BG7PRW_mjs__WEBPACK_IMPORTED_MODULE_0__/* .classDiagram_default */ .P0,
  get db() {
    return new _chunk_B4BG7PRW_mjs__WEBPACK_IMPORTED_MODULE_0__/* .ClassDB */ .dR();
  },
  renderer: _chunk_B4BG7PRW_mjs__WEBPACK_IMPORTED_MODULE_0__/* .classRenderer_v3_unified_default */ .b0,
  styles: _chunk_B4BG7PRW_mjs__WEBPACK_IMPORTED_MODULE_0__/* .styles_default */ .Ee,
  init: /* @__PURE__ */ (0,_chunk_AGHRB4JF_mjs__WEBPACK_IMPORTED_MODULE_13__/* .__name */ .eW)((cnf) => {
    if (!cnf.class) {
      cnf.class = {};
    }
    cnf.class.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
  }, "init")
};



/***/ })

}]);
//# sourceMappingURL=4135.0650cd239b6134d4bbee.js.map?v=0650cd239b6134d4bbee